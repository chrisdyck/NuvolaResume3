### 3.0.4
* collapsible panel, icon circle with arrow
* fluent-menu
* change dialog size on runtime
* add method for change tab in tabcontrol from js
* upd demo for wizard for methods examples